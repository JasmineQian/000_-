#!/bin/bash

file=/home/haixu/test.txt

line_num=$(grep -n com.mysql.jdbc.Driver $file|awk -F : '{print $1}')

for i in ${line_num[*]};do
username_num=$[${i}+7]
passwd_num=$[${i}+2]
url_num=$[${i}-1]
dbname=$[${i}-2]

sed -i "${username_num}s/<stringProp name=\"username\">.*<\/stringProp>/<stringProp name=\"password\">333qqq111<\/stringProp>/" $file
sed -i "${passwd_num}s/<stringProp name=\"password\">.*<\/stringProp>/<stringProp name=\"password\">333qqq111<\/stringProp>/" $file
sed -i "${dbname_num}s/<stringProp name=\"dataSource\">.*<\/stringProp>/<stringProp name=\"password\">333qqq111<\/stringProp>/" $file
sed -i "${url_num}s/<stringProp name=\"dbUrl\">.*<\/stringProp>/<stringProp name=\"password\">333qqq111<\/stringProp>/" $file

done

modify_db()
{
if [ ! "$mysql" ];then
echo "mysql is not config 1"
elif [ "$mysql" == true ];then
if [ ! "$mysql_username" -o ! "$mysql_passwd" -o ! "$mysql_dbname" -o ! "$mysql_dburl" ];then
echo "mysql is not config"
else
mysql_num=$(grep -n com.mysql.jdbc.Driver $file|awk -F : '{print $1}')

for i in ${mysql_num[*]};do
mysql_username_num=$[${i}+7]
mysql_passwd_num=$[${i}+2]
mysql_url_num=$[${i}-1]
mysql_dbname=$[${i}-2]

sed -i "${mysql_username_num}s/<stringProp name=\"username\">.*<\/stringProp>/<stringProp name=\"password\">$mysql_username<\/stringProp>/" $file
sed -i "${mysql_passwd_num}s/<stringProp name=\"password\">.*<\/stringProp>/<stringProp name=\"password\">$mysql_passwd<\/stringProp>/" $file
sed -i "${mysql_dbname_num}s/<stringProp name=\"dataSource\">.*<\/stringProp>/<stringProp name=\"password\">$mysql_dbname<\/stringProp>/" $file
sed -i "${mysql_url_num}s/<stringProp name=\"dbUrl\">.*<\/stringProp>/<stringProp name=\"password\">$mysql_dburl<\/stringProp>/" $file

done
fi
else 
echo "mysql status is false"
fi

if [ ! "$sqlsever" ];then
echo "sqlsever is not config 1"
elif [ "$sqlsever" == true ];then
if [ ! "$sqlserver_username" -o ! "$sqlserver_passwd" -o ! "$sqlserver_dbname" -o ! "$sqlserver_dburl" ];then
echo "sqlserver is not config"
else
sqlserver_num=$(grep -n com.mysql.jdbc.Driver $file|awk -F : '{print $1}')

for i in ${sqlserver_num[*]};do
sqlserver_username_num=$[${i}+7]
sqlserver_passwd_num=$[${i}+2]
sqlserver_url_num=$[${i}-1]
sqlserver_dbname=$[${i}-2]

sed -i "${sqlserver_username_num}s/<stringProp name=\"username\">.*<\/stringProp>/<stringProp name=\"password\">$sqlserver_username<\/stringProp>/" $file
sed -i "${sqlserver_passwd_num}s/<stringProp name=\"password\">.*<\/stringProp>/<stringProp name=\"password\">$sqlserver_passwd<\/stringProp>/" $file
sed -i "${sqlserver_dbname_num}s/<stringProp name=\"dataSource\">.*<\/stringProp>/<stringProp name=\"password\">$sqlserver_dbname<\/stringProp>/" $file
sed -i "${sqlserver_url_num}s/<stringProp name=\"dbUrl\">.*<\/stringProp>/<stringProp name=\"password\">$sqlserver_dburl<\/stringProp>/" $file

done
fi
else
echo "sqlserver status is false"
fi
}
