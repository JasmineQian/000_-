#!/bin/sh
export JAVA_HOME=/opt/jdk1.7.0_45
export RUN_HOME=/home/erizha/kioskreport
export APP_MAINCLASS=cn.com.acxiom.filetransfer.Importer
export CLASSPATH=/home/erizha/kioskreport:$CLASSPATH

CLASSPATH=$CLASSPATH:$APP_HOME/jar
for i in "$RUN_HOME"/lib/*.jar; do
	CLASSPATH="$CLASSPATH":"$i"
done

$JAVA_HOME/bin/java -Xms128m -Xmx256m -classpath $CLASSPATH  $APP_MAINCLASS $@

