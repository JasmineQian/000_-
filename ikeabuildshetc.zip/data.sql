--------------records in black table(reject 1)
use LOREALPARIS_UAT
select COUNT(1) [count], '[black transaction count]' [desc] into #reject1 FROM  lp_ipos_temp..BLACK_TRANSACTION a(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
union all
select COUNT(1) [count], '[black member count]' [desc] FROM  lp_ipos_temp..BLACK_MEMBER a(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
-----------duplicate data(reject 2)
select * into #reject2_pur FROM  lp_ipos_temp..transactions_witpos a(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and not exists (select 1 from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_PUR b
where b.RID=a.SID)
select * into #reject2_vip from lp_ipos_temp..MEMBERS_WITPOS a(nolock)
where sid in (select RID from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_VIP(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED =2)

select * into #reject3_vip from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_VIP(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (3,4,6,7)

select * into #reject3_pur from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_pur(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (2,3,5)

-----------------------imported data
select COUNT(1) [count],'Imported members' [desc] into #imported from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_VIP(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (1,5)
union all
select COUNT(1) [count],'Imported transactions' [desc] from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_pur(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (1,4)

select *  into #allimported from #reject1
union all
select * from #imported


--GetData
select COUNT(1) [count] from #reject2_pur 
select COUNT(1) [count] from #reject2_vip
select COUNT(1) [count] from #reject3_pur
select COUNT(1) [count] from #reject3_vip

select SUM([COUNT]) [transactions] from #allimported where [desc] in ('[black transaction count]','Imported transactions') 
select SUM([COUNT]) [members] from #allimported where [desc] in ('[black member count]','Imported members') 

select *  FROM  LP_IPOS_TEMP_UAT..transactions_witpos a(nolock) where SID in (select rid from  #reject3_pur)
select *  FROM  LP_IPOS_TEMP_UAT..MEMBERS_WITPOS a(nolock) where SID in (select rid from  #reject3_vip)
select CST_MEMBERSHIPNUM,name [name in files],CST_NAME [name in DB] from BCUSTOMER join #reject3_vip on CST_MEMBERSHIPNUM=member_card_no
