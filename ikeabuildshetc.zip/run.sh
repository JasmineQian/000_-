JAVA_HOME=/opt/jdk1.7.0_45
APP_HOME=$HOME/ikea_test
APP_MAINCLASS=webserviceTest.MyTest
CLASSPATH=$CLASSPATH:$APP_HOME/jar
for i in "$APP_HOME"/lib/*.jar; do
	CLASSPATH="$CLASSPATH":"$i"
done
#echo $CLASSPATH 
JAVA_OPTS="-ms512m -mx512m -Xmn256m -Djava.awt.headless=true -XX:MaxPermSize=128m"

nohup $JAVA_HOME/bin/java $JAVA_OPTS -classpath $CLASSPATH $APP_MAINCLASS $@ >out.txt 







