/****** Script for SelectTopNRows command from SSMS  ******/
   select * into #history_transation_mem from lorealparis_prod..LP_SYS_IPOS_IMPORT_HISTORY_PUR where YYYYMM=convert(varchar(8),getdate(),112)
   select * into #history_transation_non from LOP_NON_MEMBER..LP_SYS_IPOS_IMPORT_HISTORY_PUR where YYYYMM=convert(varchar(8),getdate(),112)
  --
    SELECT sum(CASE
	WHEN txdtype='NS' and price > 0 THEN quantity*price
	WHEN txdtype='NS' and price < 0 THEN 1*price
	WHEN txdtype='SR' and price > 0 THEN -1*quantity*price
	WHEN txdtype='SR' and price < 0 THEN -1*price 

     
	WHEN txdtype='STNS' and price > 0 THEN quantity*price 
	WHEN txdtype='STNS' and price < 0 THEN 1*price 
	WHEN txdtype='STSR' and price > 0 THEN -1 * quantity*price 
        WHEN txdtype='STSR' and price < 0 THEN -1*price END),count(1)
  FROM [LP_IPOS_TEMP].[dbo].[BLACK_TRANSACTION]
  where CREATION_DT>convert(varchar(10),getdate(),120)


   --imported
   select sum(a),sum(b) from
   (select cast(sum(CASE
	WHEN trans_type='NS' and value > 0 THEN quantity*value
	WHEN trans_type='NS' and value < 0 THEN 1*value
	WHEN trans_type='SR' and value > 0 THEN -1*quantity*value
	WHEN trans_type='SR' and value < 0 THEN -1*value 
	WHEN trans_type='STNS' and value > 0 THEN quantity*value 
	WHEN trans_type='STNS' and value < 0 THEN 1*value 
	WHEN trans_type='STSR' and value > 0 THEN -1 * quantity*value 
    WHEN trans_type='STSR' and value < 0 THEN -1*value END) as int) a,count(1) b,counter_no from #history_transation_mem 
    where isimported in (1,4)
    group by counter_no ) t 
	
	--rejected
   select sum(a),sum(b) from
   (select cast(sum(CASE
	WHEN trans_type='NS' and value > 0 THEN quantity*value
	WHEN trans_type='NS' and value < 0 THEN 1*value
	WHEN trans_type='SR' and value > 0 THEN -1*quantity*value
	WHEN trans_type='SR' and value < 0 THEN -1*value 
	WHEN trans_type='STNS' and value > 0 THEN quantity*value 
	WHEN trans_type='STNS' and value < 0 THEN 1*value 
	WHEN trans_type='STSR' and value > 0 THEN -1 * quantity*value 
    WHEN trans_type='STSR' and value < 0 THEN -1*value END) as int) a,count(1) b,counter_no from #history_transation_mem 
    where isimported in (2,3,5)
    group by counter_no ) t 
	
	--imported
   select sum(a),sum(b) from
   (select cast(sum(CASE
	WHEN trans_type='NS' and value > 0 THEN quantity*value
	WHEN trans_type='NS' and value < 0 THEN 1*value
	WHEN trans_type='SR' and value > 0 THEN -1*quantity*value
	WHEN trans_type='SR' and value < 0 THEN -1*value 
	WHEN trans_type='STNS' and value > 0 THEN quantity*value 
	WHEN trans_type='STNS' and value < 0 THEN 1*value 
	WHEN trans_type='STSR' and value > 0 THEN -1 * quantity*value 
    WHEN trans_type='STSR' and value < 0 THEN -1*value END) as int) a,count(1) b,counter_no from #history_transation_non 
    where isimported in (1,4)
    group by counter_no ) t 
	
	--rejected
   select sum(a),sum(b) from
   (select cast(sum(CASE
	WHEN trans_type='NS' and value > 0 THEN quantity*value
	WHEN trans_type='NS' and value < 0 THEN 1*value
	WHEN trans_type='SR' and value > 0 THEN -1*quantity*value
	WHEN trans_type='SR' and value < 0 THEN -1*value 
	WHEN trans_type='STNS' and value > 0 THEN quantity*value 
	WHEN trans_type='STNS' and value < 0 THEN 1*value 
	WHEN trans_type='STSR' and value > 0 THEN -1 * quantity*value 
    WHEN trans_type='STSR' and value < 0 THEN -1*value END) as int) a,count(1) b,counter_no from #history_transation_non
    where isimported in (2,3,5)
    group by counter_no ) t
	
	--IPOS
	select sum(cast(pur_amount as int)) total_amount,sum(cast(records as int)) total_records from LOREALPARIS_PROD..LOP_CR065 where DT>convert(varchar(10),getdate(),120)
	--
