use LOREALPARIS_PROD;
--------------records in black table(reject 1)

select COUNT(1) [count], '[black transaction count]' [desc] into #reject1 FROM  lp_ipos_temp..BLACK_TRANSACTION a(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
union all
select COUNT(1) [count], '[black member count]' [desc] FROM  lp_ipos_temp..BLACK_MEMBER a(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)

-----------duplicate data(reject 2)
-------获取当天交易数据
select * into #pur_all FROM  lp_ipos_temp..transactions_witpos a(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)


---去除非会员交易数据
select * into #reject2_pur FROM  #pur_all a where param<>'000000000'
and not exists (select 1 from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_PUR b
where b.RID=a.SID)

select * into #reject2_vip from lp_ipos_temp..MEMBERS_WITPOS a(nolock)
where sid in (select RID from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_VIP(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED =2)

select * into #reject3_vip from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_VIP(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (3,4,6,7)

select * into #reject3_pur from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_pur(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (2,3,5)



select * into #reject3_pur_nomember from LOP_NON_MEMBER..LP_SYS_IPOS_IMPORT_HISTORY_pur(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (2,3,5)

select * into #reject2_pur_nomember FROM  #pur_all a where param='000000000'
and not exists (select 1 from LOP_NON_MEMBER..LP_SYS_IPOS_IMPORT_HISTORY_PUR b
where b.RID=a.SID)

-----------------------imported data
select COUNT(1) [count],'Imported members' [desc] into #imported from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_VIP(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (1,5)
union all
select COUNT(1) [count],'Imported transactions' [desc] from LOREALPARIS_PROD..LP_SYS_IPOS_IMPORT_HISTORY_pur(nolock)
where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112)
and ISIMPORTED in (1,4)


select *  into #allimported from #reject1
union all
select * from #imported


--GetData
select COUNT(1) [count] from #reject2_pur 
select COUNT(1) [count] from #reject2_vip
select COUNT(1) [count] from #reject3_pur
select COUNT(1) [count] from #reject3_vip

select SUM([COUNT]) [transactions] from #allimported where [desc] in ('[black transaction count]','Imported transactions') 
select SUM([COUNT]) [members] from #allimported where [desc] in ('[black member count]','Imported members') 

------获取非会员交易数据记录数。
select COUNT(1) [count] from #reject2_pur_nomember
select COUNT(1) [count] from #reject3_pur_nomember
select COUNT(1) [count]  from LOP_NON_MEMBER..LP_SYS_IPOS_IMPORT_HISTORY_pur(nolock) where CONVERT(varchar(8),CREATION_DT,112)=CONVERT(varchar(8),GETDATE(),112) and ISIMPORTED in (1,4)



select * from #reject2_pur 
select * from #reject2_pur_nomember
select * from #reject2_vip

select *  FROM  lp_ipos_temp..transactions_witpos a(nolock) where SID in (select rid from  #reject3_pur)
select *  FROM  lp_ipos_temp..MEMBERS_WITPOS a(nolock) where SID in (select rid from  #reject3_vip)
select CST_MEMBERSHIPNUM,name [name in files],CST_NAME [name in DB] from BCUSTOMER join bmembership on mmb_cst_id=cst_id join #reject3_vip on mmb_MEMBERSHIPNUM=member_card_no

select * from #reject3_pur_nomember

--ExportData
INSERT INTO LP_SYS_IPOS_DATALOAD_HISTORY (IMP_FILE_TRANS,IMP_FILE_MEMBER,IMP_DUP_TRANS,IMP_DUP_MEMBER,IMP_INVALID_TRANS,IMP_INVALID_MEMBER,IMP_OK_TRANS,IMP_OK_MEMBER,IMP_DB_TOTAL_TRANS,IMP_DB_TOTAL_MEMBER,EXP_POINTS,EXP_MEMBER,DTLOAD_DATE)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
